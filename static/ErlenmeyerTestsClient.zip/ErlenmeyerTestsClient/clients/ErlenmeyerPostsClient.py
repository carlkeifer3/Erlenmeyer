#
#  ErlenmeyerPostsClient.py
#  ErlenmeyerTestsClient
#
#  Created by pcperini on Feb 11, 2013.
#

# imports
import ErlenmeyerClient

class ErlenmeyerPostsClient(ErlenmeyerClient.ErlenmeyerClient):
    
    def __init__(self):
        self.className = 'ErlenmeyerPosts'
        
    def getAuthor(self, uuid):
        return self.getRelationshipObjects(uuid, 'author')
        
    def postAuthor(self, uuid, authorUUID):
        return self.postRelationshipObject(uuid, 'author', authorUUID)