#
#  ErlenmeyerClient.py
#  ErlenmeyerTestsClient
#
#  Created by pcperini on Feb 11, 2013.
#

# imports
import requests

class ErlenmeyerClient:

    def getAll(self):
        requestURL = 'http://127.0.0.1:8080/%s' % (self.className)
        request = requests.get(requestURL)
        return request.json()
        
    def putOne(self, uuid, properties = {}):
        requestURL = 'http://127.0.0.1:8080/%s' % (self.className)
        requestData = {'uuid': uuid}
        requestData.update(properties)
        request = requests.put(requestURL, data = requestData)
        return request.text
        
    def getOne(self, uuid):
        requestURL = 'http://127.0.0.1:8080/%s/%s' % (self.className, uuid)
        request = requests.get(requestURL)
        return request.json()
        
    def updateOne(self, uuid, newProperties):
        requestURL = 'http://127.0.0.1:8080/%s/%s' % (self.className, uuid)
        requestData = newProperties
        request = requests.post(requestURL, data = requestData)
        return request.text
        
    def deleteOne(self, uuid):
        requestURL = 'http://127.0.0.1:8080/%s/%s' % (self.className, uuid)
        request = requests.delete(requestURL)
        return request.text
        
    def getRelationshipObjects(self, uuid, relationshipName):
        requestURL = 'http://127.0.0.1:8080/%s/%s/%s' % (self.className, uuid, relationshipName)
        request = requests.get(requestURL)
        return request.json()
        
    def putRelationshipObject(self, uuid, relationshipName, relationshipObjectUUID):
        requestURL = 'http://127.0.0.1:8080/%s/%s/%s' % (self.className, uuid, relationshipName)
        requestData = {'%sObject' % (relationshipName): relationshipObjectUUID}
        request = requests.put(requestURL, data = requestData)
        return request.text
        
    def postRelationshipObject(self, uuid, relationshipName, relationshipObjectUUID):
        requestURL = 'http://127.0.0.1:8080/%s/%s/%s' % (self.className, uuid, relationshipName)
        requestData = {'%sObject' % (relationshipName): relationshipObjectUUID}
        request = requests.post(requestURL, data = requestData)
        return request.text
        
    def deleteRelationshipObject(self, uuid, relationshipName, relationshipObjectUUID):
        requestURL = 'http://127.0.0.1:8080/%s/%s/%s' % (self.className, uuid, relationshipName)
        requestData = {'%sObject' % (relationshipName): relationshipObjectUUID}
        request = requests.delete(requestURL, params = requestData)
        return request.text