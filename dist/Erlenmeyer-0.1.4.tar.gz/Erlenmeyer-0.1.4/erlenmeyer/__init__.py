#
#  __init__.py
#  Erlenmeyer
#
#  Created by Patrick Perini on February 3, 2013.
#  See LICENSE.txt for licensing information.
#