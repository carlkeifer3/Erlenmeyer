#
#  ErlenmeyerUsersClient.py
#  ErlenmeyerTestsClient
#
#  Created by pcperini on Feb 11, 2013.
#

# imports
import ErlenmeyerClient

class ErlenmeyerUsersClient(ErlenmeyerClient.ErlenmeyerClient):
    
    def __init__(self):
        self.className = 'ErlenmeyerUsers'
        
    def getGroups(self, uuid):
        return self.getRelationshipObjects(uuid, 'groups')
        
    def putGroup(self, uuid, groupUUID):
        return self.putRelationshipObject(uuid, 'groups', groupUUID)
        
    def deleteGroup(self, uuid, groupUUID):
        return self.deleteRelationshipObject(uuid, 'groups', groupUUID)
        
    def getPosts(self, uuid):
        return self.getRelationshipObjects(uuid, 'posts')
        
    def putPost(self, uuid, postUUID):
        return self.putRelationshipObject(uuid, 'posts', postUUID)
        
    def deletePost(self, uuid, postUUID):
        return self.deleteRelationshipObject(uuid, 'posts', postUUID)