#
#  ErlenmeyerGroupsClient.py
#  ErlenmeyerTestsClient
#
#  Created by pcperini on Feb 11, 2013.
#

# imports
import ErlenmeyerClient

class ErlenmeyerGroupsClient(ErlenmeyerClient.ErlenmeyerClient):
    
    def __init__(self):
        self.className = 'ErlenmeyerGroups'
        
    def getMembers(self, uuid):
        return self.getRelationshipObjects(uuid, 'members')
        
    def putMember(self, uuid, memberUUID):
        return self.putRelationshipObject(uuid, 'members', memberUUID)
        
    def deleteMember(self, uuid, memberUUID):
        return self.deleteRelationshipObject(uuid, 'members', memberUUID)