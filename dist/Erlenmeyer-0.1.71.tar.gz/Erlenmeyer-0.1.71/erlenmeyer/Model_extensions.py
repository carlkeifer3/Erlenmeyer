#
#  Model_extensions.py
#  Erlenmeyer
#
#  Created by Patrick Perini on February 7, 2013.
#  See LICENSE.txt for licensing information.
#

# imports
from flask.ext.sqlalchemy import SQLAlchemy

# accessors
def __iter__(self):
    for key in self.__dict__:
        if not key.startswith('_'):
            yield (key, self.__dict__[key])  

# mutators
def update(self, properties):
    print dict(self), properties
    for key in properties:
        setattr(self, key, properties[key])
    print dict(self)

def save(self):
    self.__database__.session.add(self)
    self.__database__.session.commit()
    
def delete(self):
    self.__database__.session.delete(self)
    self.__database__.session.commit()